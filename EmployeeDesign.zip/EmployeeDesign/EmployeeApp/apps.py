from django.apps import AppConfig


class NectarConfig(AppConfig):
    name = 'Nectar'
